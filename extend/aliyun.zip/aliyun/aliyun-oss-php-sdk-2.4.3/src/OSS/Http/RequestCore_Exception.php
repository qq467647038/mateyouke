<?php

namespace OSS\Http;

class RequestCore_Exception extends \Exception
{

}